import React, { useState } from "react";
import "./Sidebar.css";

const Sidebar = ({ sidebar, setSelectedCategory }) => {
  const [openMenu, setOpenMenu] = useState(null);
  const [activeMenu, setActiveMenu] = useState("Explore");
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = (menu) => setOpenMenu(openMenu === menu ? null : menu);

  const handleClick = (category) => {
    setSelectedCategory(category);
    setActiveMenu(category);
    setIsOpen(false);
  };

  const navItems = [
    { label: "Explore", category: "Explore" },
    { label: "Articles", category: "Articles" },
    { label: "Portfolio", category: "ogfolio" },
  ];

  const toolItems = [
    { label: "Marketplace", category: "Marketplace" },
    {
      label: "Libraries", category: "Libraries",
      sub: [
        { label: "UI Kits", category: "UI Kits" },
        { label: "Frameworks", category: "Frameworks" },
      ],
    },
    {
      label: "Design", category: "Design",
      sub: [
        { label: "Logos", category: "Logos" },
        { label: "Illustrations", category: "Illustrations" },
      ],
    },
    {
      label: "AI", category: "AI",
      sub: [
        { label: "Chatbots", category: "Chatbots" },
        { label: "Generators", category: "Generators" },
      ],
    },
    { label: "No-Code", category: "No-Code" },
    { label: "Startups", category: "Startups" },
    { label: "Marketing", category: "Marketing" },
    { label: "Video Editing & Generation", category: "Video" },
    { label: "E-commerce Builder", category: "E-commerce" },
  ];

  return (
    <>
      {/* Hamburger */}
      <div className={`hamburger ${isOpen ? "open" : ""}`} onClick={() => setIsOpen(!isOpen)}>
        <div /><div /><div />
      </div>

      {/* Sidebar */}
      <div className={`sidebar ${sidebar ? "" : "small-sidebar"} ${isOpen ? "show" : ""}`}>
        <div className="sidebar-header">
          <h2>🔗 LinqGram</h2>
        </div>

        {/* Main nav */}
        <div className="menu-section">
          {navItems.map((item) => (
            <div key={item.category} className={`side-link ${activeMenu === item.category ? "active" : ""}`} onClick={() => handleClick(item.category)}>
              <p>{item.label}</p>
            </div>
          ))}
        </div>

        <h4 className="menu-label">Tools</h4>

        {toolItems.map((item) => (
          <div key={item.category}>
            <div
              className={`side-link ${activeMenu === item.category ? "active" : ""}`}
              onClick={() => {
                if (item.sub) toggleMenu(item.category);
                handleClick(item.category);
              }}
            >
              <p>{item.label}</p>
              {item.sub && <span style={{ fontSize: "10px", color: "#666" }}>{openMenu === item.category ? "▲" : "▼"}</span>}
            </div>

            {item.sub && openMenu === item.category && (
              <div className="submenu">
                {item.sub.map((s) => (
                  <p key={s.category} className={activeMenu === s.category ? "active" : ""} onClick={() => handleClick(s.category)}>
                    {s.label}
                  </p>
                ))}
              </div>
            )}
          </div>
        ))}

        <div className="bottom-section">
          <div className="side-link submit-link" onClick={() => handleClick("contact")}>
            <p>+ Submit a Tool</p>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
