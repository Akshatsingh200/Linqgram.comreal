import React from "react";
import "./FeedCommon.css";
import "./Exploorer.css";
import SimpleCard from "../Cards/SimpleCard";

const ExploreFeed = () => {
  const tools = [
    { title: "Figma", img: "https://logo.clearbit.com/figma.com", items: "Collaborative interface design tool", link: "https://www.figma.com/", category: "Design" },
    { title: "Framer", img: "https://logo.clearbit.com/framer.com", items: "Interactive prototyping & web design", link: "https://www.framer.com/", category: "Design" },
    { title: "Canva", img: "https://logo.clearbit.com/canva.com", items: "Create stunning visuals online", link: "https://www.canva.com/", category: "Design" },
    { title: "Adobe XD", img: "https://logo.clearbit.com/adobe.com", items: "UI/UX design and prototyping", link: "https://www.adobe.com/products/xd.html", category: "Design" },
    { title: "Sketch", img: "https://logo.clearbit.com/sketch.com", items: "Vector UI design app for macOS", link: "https://www.sketch.com/", category: "Design" },
    { title: "GitHub", img: "https://logo.clearbit.com/github.com", items: "Code hosting & collaboration platform", link: "https://github.com/", category: "Development" },
    { title: "GitLab", img: "https://logo.clearbit.com/gitlab.com", items: "DevOps & CI/CD platform", link: "https://gitlab.com/", category: "Development" },
    { title: "VS Code", img: "https://logo.clearbit.com/visualstudio.com", items: "Powerful and fast code editor", link: "https://code.visualstudio.com/", category: "Development" },
    { title: "Stack Overflow", img: "https://logo.clearbit.com/stackoverflow.com", items: "Q&A for developers worldwide", link: "https://stackoverflow.com/", category: "Development" },
    { title: "CodePen", img: "https://logo.clearbit.com/codepen.io", items: "Online code editor for front-end dev", link: "https://codepen.io/", category: "Development" },
    { title: "Replit", img: "https://logo.clearbit.com/replit.com", items: "Collaborative online IDE", link: "https://replit.com/", category: "Development" },
    { title: "Vercel", img: "https://logo.clearbit.com/vercel.com", items: "Deploy React & Next.js apps easily", link: "https://vercel.com/", category: "Hosting" },
    { title: "Netlify", img: "https://logo.clearbit.com/netlify.com", items: "Powerful hosting & CI/CD for web apps", link: "https://www.netlify.com/", category: "Hosting" },
    { title: "Firebase", img: "https://logo.clearbit.com/firebase.google.com", items: "Backend services & hosting by Google", link: "https://firebase.google.com/", category: "Hosting" },
    { title: "Heroku", img: "https://logo.clearbit.com/heroku.com", items: "Platform as a service for apps", link: "https://www.heroku.com/", category: "Hosting" },
    { title: "Render", img: "https://logo.clearbit.com/render.com", items: "Fast cloud hosting platform", link: "https://render.com/", category: "Hosting" },
    { title: "Notion", img: "https://logo.clearbit.com/notion.so", items: "All-in-one workspace for notes & docs", link: "https://www.notion.so/", category: "Productivity" },
    { title: "Trello", img: "https://logo.clearbit.com/trello.com", items: "Organize and plan projects visually", link: "https://trello.com/", category: "Productivity" },
    { title: "Slack", img: "https://logo.clearbit.com/slack.com", items: "Team communication and collaboration", link: "https://slack.com/", category: "Productivity" },
    { title: "Discord", img: "https://logo.clearbit.com/discord.com", items: "Voice & text chat for communities", link: "https://discord.com/", category: "Productivity" },
    { title: "Linear", img: "https://logo.clearbit.com/linear.app", items: "Issue tracking for modern teams", link: "https://linear.app/", category: "Productivity" },
    { title: "Unsplash", img: "https://logo.clearbit.com/unsplash.com", items: "Free high-quality stock images", link: "https://unsplash.com/", category: "Productivity" },
  ];

  return (
    <div className="feed explore-feed">
      <div className="explore-banner">
        <h1>🚀 Explore Top Tools</h1>
        <p>Your all-in-one resource hub for design, development, hosting, and productivity tools.</p>
      </div>

      {["Design", "Development", "Hosting", "Productivity"].map((cat) => (
        <div key={cat} className="tool-category">
          <h2 className="category-title">{cat}</h2>
          <div className="feed-grid">
            {tools.filter((t) => t.category === cat).map((tool, i) => (
              <a key={i} href={tool.link} target="_blank" rel="noopener noreferrer" className="tool-card-link">
                <SimpleCard title={tool.title} img={tool.img} items={tool.items} />
              </a>
            ))}
          </div>
        </div>
      ))}

      <div className="explore-footer">
        <h2>✨ More tools coming soon...</h2>
        <p>We keep this list updated with the best new tools for creators and developers.</p>
      </div>
    </div>
  );
};

export default ExploreFeed;
