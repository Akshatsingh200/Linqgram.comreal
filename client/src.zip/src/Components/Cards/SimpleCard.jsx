import React from "react";

export default function SimpleCard({ title, img, items, onClick }) {
  return (
    <div
      onClick={onClick}
      className="group relative bg-[#0c0c0c] rounded-2xl overflow-hidden border border-[#1f1f1f] hover:border-[#00c6ff]/40 shadow-lg hover:shadow-[#00c6ff]/20 transition-all duration-500 cursor-pointer flex flex-col h-[380px]"
    >
      {/* Image */}
      <div className="h-[180px] overflow-hidden bg-[#111] flex items-center justify-center">
        <img
          src={img}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-500 ease-out group-hover:scale-110"
          onError={(e) => {
            e.target.onerror = null;
            e.target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(title)}&background=1a1a2e&color=fff&size=200`;
          }}
        />
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col justify-between p-5">
        <div>
          <h3 className="text-white text-base font-semibold mb-2 tracking-wide group-hover:text-[#00c6ff] transition-colors line-clamp-1">
            {title}
          </h3>
          <p className="text-gray-400 text-sm leading-relaxed line-clamp-3">{items}</p>
        </div>
        <div className="mt-4">
          <button className="w-full py-2 bg-gradient-to-r from-[#0072ff] to-[#00c6ff] text-white text-sm font-medium rounded-lg shadow-md hover:shadow-[#00c6ff]/50 transition-all duration-300">
            Explore →
          </button>
        </div>
      </div>

      {/* Glow overlay */}
      <div className="absolute inset-0 opacity-0 group-hover:opacity-10 bg-gradient-to-r from-[#00c6ff] to-[#0072ff] transition-opacity duration-500 pointer-events-none" />
    </div>
  );
}
